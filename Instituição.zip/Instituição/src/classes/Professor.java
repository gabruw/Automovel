package classes;

import java.util.Date;

public class Professor {
    private int Matricula;
    private int NumeroAulas;
    private String Nome;
    private String Curso;
    private Date DataAdimicao;
    private int DiasLetivos;
    private String Titulacao;
    private double ValorHoraAula;
    private double Salario;
    
    public void CalcSalario(){
        ValorHoraAula = 35;
        NumeroAulas= 50;
        Salario = (ValorHoraAula * NumeroAulas) - ((ValorHoraAula * NumeroAulas) * 11/100);
        
        if(Salario > 2.400){
            Salario = Salario - (Salario * 15/100);
        }
    }
    
    public String Exibir() {
        return "Matricula: " + Matricula 
                + "\nNome: " + Nome 
                + "\nCurso: " + Curso 
                + "\nData Adimicao: " + DataAdimicao 
                + "\nDias Letivos: " + DiasLetivos 
                + "\nTitulacao: " + Titulacao 
                + "\nValor Hora-aula: " + ValorHoraAula
                + "\nSalário: " + Salario;
    }
    
    public void CalcTitulacao(){
        switch(Titulacao){
            case "Mestrado":
                Salario = Salario + (Salario * 5/100);
                break;
            case "Doutorado":
                Salario = Salario + (Salario * 15/100);
                break;
            case "Pós-Doutorado":
                Salario = Salario + (Salario * 25/100);
                break;
        }
    }

    public Professor() {
        
    }
    
    public Professor(int Matricula, int NumeroAulas, String Nome, String Curso, Date DataAdimicao, int DiasLetivos, String Titulacao, double ValorHoraAula) {
        this.Matricula = Matricula;
        this.NumeroAulas = NumeroAulas;
        this.Nome = Nome;
        this.Curso = Curso;
        this.DataAdimicao = DataAdimicao;
        this.DiasLetivos = DiasLetivos;
        this.Titulacao = Titulacao;
        this.ValorHoraAula = ValorHoraAula;
    }
    
    public int getMatricula() {
        return Matricula;
    }

    public void setMatricula(int Matricula) {
        this.Matricula = Matricula;
    }

    public int getNumeroAulas() {
        return NumeroAulas;
    }

    public void setNumeroAulas(int NumeroAulas) {
        this.NumeroAulas = NumeroAulas;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getCurso() {
        return Curso;
    }

    public void setCurso(String Curso) {
        this.Curso = Curso;
    }

    public Date getDataAdimicao() {
        return DataAdimicao;
    }

    public void setDataAdimicao(Date DataAdimicao) {
        this.DataAdimicao = DataAdimicao;
    }

    public int getDiasLetivos() {
        return DiasLetivos;
    }

    public void setDiasLetivos(int DiasLetivos) {
        this.DiasLetivos = DiasLetivos;
    }

    public String getTitulacao() {
        return Titulacao;
    }

    public void setTitulacao(String Titulacao) {
        this.Titulacao = Titulacao;
    }

    public double getValorHoraAula() {
        return ValorHoraAula;
    }

    public void setValorHoraAula(double ValorHoraAula) {
        this.ValorHoraAula = ValorHoraAula;
    }

    public double getSalario() {
        return Salario;
    }
}